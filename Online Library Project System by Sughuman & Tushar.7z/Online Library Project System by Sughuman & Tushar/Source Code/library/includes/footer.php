   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   &copy;Online Library Management System | Designed by : Sughuman Mahajan & Tushar</a> 
                </div>

            </div>
        </div>
    </section>